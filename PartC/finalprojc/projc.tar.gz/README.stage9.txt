Writeup by Ethan Chan 1801654130

a) Yes I used code from Beej’s Guide to Network Programming and I used code from Unix Network Programming by W. Richard Stevens.

b) Yes I completed this stage. The program will exit if ICMP/TCP not sent within 20seconds.